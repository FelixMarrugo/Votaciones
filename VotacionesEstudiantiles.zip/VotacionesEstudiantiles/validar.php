<?php

    $rola = "Administrador";
    $rolb = "Votante";

    if (isset($_POST['enviar'])) {
        require("conexion.php");

        session_start();
        $nombre = $_POST["usuario"];
        $pw = $_POST["pw"];


        $consulta = ("SELECT * FROM usuarios WHERE usuario = '$nombre' AND pass = '$pw'");
        echo $consulta;

        if(($resultado = $myqli->query($consulta)))
        {
    
            while($row = $resultado->fetch_array())
            {

                $OKU = $row["usuario"];
                $OKP = $row["pass"];
                $rol = $row["rol"];
                $_SESSION['login'] = $row["usuario"];
            }
            $resultado->close();
        }else{
            echo "No entre al if, algo paso";
        }
        $myqli->close();
    }

    //Validar que redireccionemos a los usuarios
    if($nombre == $OKU && $pw = $OKP && $rol == $rola)
    {
        $_SESSION["logueado"] = TRUE;
        header("location: administrador.php");
    } 
    elseif ($nombre == $OKU && $$pw = $OKP && $rol == $rolb) {
        $_SESSION["logueado"] = TRUE;
        header("location: votante.php");
    }
    else{
       echo "HOla";
    }
?>