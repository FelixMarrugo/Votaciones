<?php  
    include ("conexion.php"); //Incluimos la conexion

    //Capturamos los datos
    $usuario = $_POST['usuario'];
    $pw = $_POST['pw'];
    $rol = $_POST['rol'];

    $insertar = "INSERT INTO usuarios(usuario, pass, rol) VALUES ('$usuario', '$pw', '$rol')";
    echo $insertar;
    if(mysqli_query($myqli, $insertar))
    {
    ?>
        <script language = "javascript">
            alert("Datos ingrados correctamente.");
            location.href = "administrador.php";
        </script>
    <?php
    } 
    else{
    ?>
        <script language="javascript">
            alert('No es posible ingresar los datos.');
            location.href="administrador.php";
        </script>
    <?php
    }
?>