<!DOCTYPE cshtml>
<html lang="es">
    <head>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="js/bootstrap.min.js">
    <link rel="stylesheet" href="./css/estilosindex.css">
    </head>

<!-- Diseño del tarjeton -->
<div class="container">
    <div class="row justify-content-center">
        <div class="col">
            <div class="card" style="width: 250px;">
                <button class="btn"> <img src="https://api.lorem.space/image/face?w=150&amp;amp;amp;amp;h=220" style="width: 150px;" class="card-img-top" alt="..."> </button>
                <div class="card-body">
                    <h5 class="card-title">Nombre del Candidato</h5>
                    <p class="card-text">Grado: ...... Grupo: ...... </p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card" style="width: 250px; margin-top:15px;">
                <button class="btn"> <img src="https://api.lorem.space/image/face?w=150&amp;amp;amp;amp;h=220" style="width: 150px;" class="card-img-top" alt="..."> </button>
                <div class="card-body">
                    <h5 class="card-title">Nombre del Candidato</h5>
                    <p class="card-text">Grado: ...... Grupo: ...... </p>
                </div>
            </div>
        </div>
    
        <div class="col">
            <div class="card" style="width: 250px; margin-top: 15px;">
                <button class="btn"> <img src="https://api.lorem.space/image/face?w=150&amp;amp;amp;amp;h=220" style="width: 150px;" class="card-img-top" alt="..."> </button>
                <div class="card-body">
                    <h5 class="card-title">Nombre del Candidato</h5>
                    <p class="card-text">Grado: ...... Grupo: ...... </p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card" style="width: 250px; margin-top:15px;">
                <div class="card-body">
                    <button class="btn btn-primary" ><h5 class="card-title">Voto en Blaco</h5></button>
                </div>
            </div>
            <div>
                <a href="./index.php">
                    <button type="button" class="salir" style="width: 40%; margin-left: 250px;">Salir</button>
                </a>
            </div>
        </div>
    </div>
</div>


</html>