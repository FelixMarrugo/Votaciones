<?php 

$servidor = "localhost";
$user = "root";
$pw = "f3l1xjun10r";
$db = "grupo50";

$myqli = new mysqli($servidor, $user, $pw, $db);

if($myqli->connect_errno){
    echo "<strong>,h2>Error al conectarse a la base de datos</h2></strong>".$msqli->connect_errno;
}

return $myqli;
?>